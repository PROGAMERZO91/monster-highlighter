package com.example.monsterhighlighter.mixin;

import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.player.Player.SleepResult;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(Player.class)
public class PlayerMixin {

    @Inject(method = "startSleepInBed", at = @At("RETURN"))
    private void onSleep(Vec3 pos, CallbackInfoReturnable<SleepResult> cir) {

        if (cir.getReturnValue() == SleepResult.NOT_SAFE) {

            Player player = (Player)(Object)this;

            AABB box = new AABB(
                    pos.x - 8, pos.y - 5, pos.z - 8,
                    pos.x + 8, pos.y + 5, pos.z + 8
            );

            List<Monster> mobs = player.level().getEntitiesOfClass(
                    Monster.class,
                    box
            );

            for (Monster mob : mobs) {
                mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100));
            }
        }
    }
}
