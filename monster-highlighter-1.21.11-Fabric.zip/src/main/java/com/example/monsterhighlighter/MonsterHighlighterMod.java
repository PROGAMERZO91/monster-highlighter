package com.example.monsterhighlighter;

import net.fabricmc.api.ModInitializer;

public class MonsterHighlighterMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("Monster Highlighter 1.21.11 Loaded!");
    }
}
